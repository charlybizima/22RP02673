import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class AddItemServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        try {
            String name = request.getParameter("name");
            double price = Double.parseDouble(request.getParameter("price"));

            Cookie[] cookies = request.getCookies();
            String cartItems = "";
            if (cookies != null) {
                for (Cookie cookie : cookies) {
                    if (cookie.getName().equals("cart")) {
                        cartItems = cookie.getValue();
                        break;
                    }
                }
            }
            cartItems += (cartItems.isEmpty() ? "" : ",") + name + ":" + price;
            
            Cookie cartCookie = new Cookie("cart", cartItems);
            cartCookie.setMaxAge(24 * 60 * 60); // 1 day
            response.addCookie(cartCookie);

            out.println("<html><body>");
            out.println("<h2>Item Added to Cart</h2>");
            out.println("<p>Name: " + name + "</p>");
            out.println("<p>Price: $" + String.format("%.2f", price) + "</p>");
            out.println("<p>Current cart: " + cartItems + "</p>");
            out.println("<a href='index.html'>Back to main page</a>");
            out.println("</body></html>");
        } catch (Exception e) {
            out.println("<html><body>");
            out.println("<h2>Error Adding Item</h2>");
            out.println("<p>Error: " + e.getMessage() + "</p>");
            out.println("<a href='index.html'>Back to main page</a>");
            out.println("</body></html>");
        }
    }
}